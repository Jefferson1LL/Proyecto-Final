/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matrimonio;

/**
 *
 * @author PC-HOME
 */
public class test {
    ClsOficinaBO ebo = new ClsOficinaBO();
    ClsOficina ofi = new ClsOficina();
    ClsFuncionario fun = new ClsFuncionario();
    String mensaje="";
    
    public void insertar(){
        ofi.setDireccionOficina("Guayaquil");
        ofi.setProvinciaOficina("Guayas");
        ofi.setCantonOficina("Naranjal");
        ofi.setParroquiaOficina("Naranjal");
        ofi.setFechaMatrimonio("2003/05/03");
        ofi.setActaOficina(211144);
        ofi.setNumeroHijos(1);
        ofi.setBienes('S');
        
        mensaje=ebo.agregarOficina(ofi);
        System.out.println(mensaje);
    }
    
    public void insertar2(){
        fun.setNombreApellidoFuncionario("Andres Palomino");
        fun.setCIFuncionario(1721130993);
        fun.setObservacion("Sin observacion");
    }
    public static void main(String[] args) {
        test Test = new test();
        Test.insertar();
        Test.insertar2();
    }
}

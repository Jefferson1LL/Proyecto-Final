/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matrimonio;

/**
 *
 * @author PC-HOME
 */
public class ClslaContrayente {
    private String NombreApellidos2;
    private char Nacionalidad2;
    private int CI2;
    private String FechNacimiento2;
    private int Edad2;
    private int NumeroMatrimonios2;
    private char EstadoCivil2;
    private char Etnica2;
    private String LeeryEscribir2;
    private char Instruccion2;
    private String ProvinciaContrayente2;
    private String CantonContrayente2;
    private String ParroquiaContrayente2;
    private String LocalidadContrayente2;

    public ClslaContrayente() {
    }

    public ClslaContrayente(String NombreApellidos2, char Nacionalidad2, int CI2, String FechNacimiento2, int Edad2, int NumeroMatrimonios2, char EstadoCivil2, char Etnica2, String LeeryEscribir2, char Instruccion2, String ProvinciaContrayente2, String CantonContrayente2, String ParroquiaContrayente2, String LocalidadContrayente2) {
        this.NombreApellidos2 = NombreApellidos2;
        this.Nacionalidad2 = Nacionalidad2;
        this.CI2 = CI2;
        this.FechNacimiento2 = FechNacimiento2;
        this.Edad2 = Edad2;
        this.NumeroMatrimonios2 = NumeroMatrimonios2;
        this.EstadoCivil2 = EstadoCivil2;
        this.Etnica2 = Etnica2;
        this.LeeryEscribir2 = LeeryEscribir2;
        this.Instruccion2 = Instruccion2;
        this.ProvinciaContrayente2 = ProvinciaContrayente2;
        this.CantonContrayente2 = CantonContrayente2;
        this.ParroquiaContrayente2 = ParroquiaContrayente2;
        this.LocalidadContrayente2 = LocalidadContrayente2;
    }

    public String getNombreApellidos2() {
        return NombreApellidos2;
    }

    public void setNombreApellidos2(String NombreApellidos2) {
        this.NombreApellidos2 = NombreApellidos2;
    }

    public char getNacionalidad2() {
        return Nacionalidad2;
    }

    public void setNacionalidad2(char Nacionalidad2) {
        this.Nacionalidad2 = Nacionalidad2;
    }

    public int getCI2() {
        return CI2;
    }

    public void setCI2(int CI2) {
        this.CI2 = CI2;
    }

    public String getFechNacimiento2() {
        return FechNacimiento2;
    }

    public void setFechNacimiento2(String FechNacimiento2) {
        this.FechNacimiento2 = FechNacimiento2;
    }

    public int getEdad2() {
        return Edad2;
    }

    public void setEdad2(int Edad2) {
        this.Edad2 = Edad2;
    }

    public int getNumeroMatrimonios2() {
        return NumeroMatrimonios2;
    }

    public void setNumeroMatrimonios2(int NumeroMatrimonios2) {
        this.NumeroMatrimonios2 = NumeroMatrimonios2;
    }

    public char getEstadoCivil2() {
        return EstadoCivil2;
    }

    public void setEstadoCivil2(char EstadoCivil2) {
        this.EstadoCivil2 = EstadoCivil2;
    }

    public char getEtnica2() {
        return Etnica2;
    }

    public void setEtnica2(char Etnica2) {
        this.Etnica2 = Etnica2;
    }

    public String getLeeryEscribir2() {
        return LeeryEscribir2;
    }

    public void setLeeryEscribir2(String LeeryEscribir2) {
        this.LeeryEscribir2 = LeeryEscribir2;
    }

    public char getInstruccion2() {
        return Instruccion2;
    }

    public void setInstruccion2(char Instruccion2) {
        this.Instruccion2 = Instruccion2;
    }

    public String getProvinciaContrayente2() {
        return ProvinciaContrayente2;
    }

    public void setProvinciaContrayente2(String ProvinciaContrayente2) {
        this.ProvinciaContrayente2 = ProvinciaContrayente2;
    }

    public String getCantonContrayente2() {
        return CantonContrayente2;
    }

    public void setCantonContrayente2(String CantonContrayente2) {
        this.CantonContrayente2 = CantonContrayente2;
    }

    public String getParroquiaContrayente2() {
        return ParroquiaContrayente2;
    }

    public void setParroquiaContrayente2(String ParroquiaContrayente2) {
        this.ParroquiaContrayente2 = ParroquiaContrayente2;
    }

    public String getLocalidadContrayente2() {
        return LocalidadContrayente2;
    }

    public void setLocalidadContrayente2(String LocalidadContrayente2) {
        this.LocalidadContrayente2 = LocalidadContrayente2;
    }

    @Override
    public String toString() {
        return "ClslaContrayente{" + "NombreApellidos2=" + NombreApellidos2 + ", Nacionalidad2=" + Nacionalidad2 + ", CI2=" + CI2 + ", FechNacimiento2=" + FechNacimiento2 + ", Edad2=" + Edad2 + ", NumeroMatrimonios2=" + NumeroMatrimonios2 + ", EstadoCivil2=" + EstadoCivil2 + ", Etnica2=" + Etnica2 + ", LeeryEscribir2=" + LeeryEscribir2 + ", Instruccion2=" + Instruccion2 + ", ProvinciaContrayente2=" + ProvinciaContrayente2 + ", CantonContrayente2=" + CantonContrayente2 + ", ParroquiaContrayente2=" + ParroquiaContrayente2 + ", LocalidadContrayente2=" + LocalidadContrayente2 + '}';
    }
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matrimonio;

/**
 *
 * @author PC-HOME
 */
public class ClsContrayente {
     private String NombreApellidos1;
    private char Nacionalidad1;
    private int CI1;
    private String FechNacimiento1;
    private int Edad1;
    private int NumeroMatrimonios1;
    private char EstadoCivil1;
    private char Etnica1;
    private String LeeryEscribir1;
    private char Instruccion1;
    private String ProvinciaContrayente1;
    private String CantonContrayente1;
    private String ParroquiaContrayente1;
    private String LocalidadContrayente1;

    public ClsContrayente() {
    }

    public ClsContrayente(String NombreApellidos1, char Nacionalidad1, int CI1, String FechNacimiento1, int Edad1, int NumeroMatrimonios1, char EstadoCivil1, char Etnica1, String LeeryEscribir1, char Instruccion1, String ProvinciaContrayente1, String CantonContrayente1, String ParroquiaContrayente1, String LocalidadContrayente1) {
        this.NombreApellidos1 = NombreApellidos1;
        this.Nacionalidad1 = Nacionalidad1;
        this.CI1 = CI1;
        this.FechNacimiento1 = FechNacimiento1;
        this.Edad1 = Edad1;
        this.NumeroMatrimonios1 = NumeroMatrimonios1;
        this.EstadoCivil1 = EstadoCivil1;
        this.Etnica1 = Etnica1;
        this.LeeryEscribir1 = LeeryEscribir1;
        this.Instruccion1 = Instruccion1;
        this.ProvinciaContrayente1 = ProvinciaContrayente1;
        this.CantonContrayente1 = CantonContrayente1;
        this.ParroquiaContrayente1 = ParroquiaContrayente1;
        this.LocalidadContrayente1 = LocalidadContrayente1;
    }

    public String getNombreApellidos1() {
        return NombreApellidos1;
    }

    public void setNombreApellidos1(String NombreApellidos1) {
        this.NombreApellidos1 = NombreApellidos1;
    }

    public char getNacionalidad1() {
        return Nacionalidad1;
    }

    public void setNacionalidad1(char Nacionalidad1) {
        this.Nacionalidad1 = Nacionalidad1;
    }

    public int getCI1() {
        return CI1;
    }

    public void setCI1(int CI1) {
        this.CI1 = CI1;
    }

    public String getFechNacimiento1() {
        return FechNacimiento1;
    }

    public void setFechNacimiento1(String FechNacimiento1) {
        this.FechNacimiento1 = FechNacimiento1;
    }

    public int getEdad1() {
        return Edad1;
    }

    public void setEdad1(int Edad1) {
        this.Edad1 = Edad1;
    }

    public int getNumeroMatrimonios1() {
        return NumeroMatrimonios1;
    }

    public void setNumeroMatrimonios1(int NumeroMatrimonios1) {
        this.NumeroMatrimonios1 = NumeroMatrimonios1;
    }

    public char getEstadoCivil1() {
        return EstadoCivil1;
    }

    public void setEstadoCivil1(char EstadoCivil1) {
        this.EstadoCivil1 = EstadoCivil1;
    }

    public char getEtnica1() {
        return Etnica1;
    }

    public void setEtnica1(char Etnica1) {
        this.Etnica1 = Etnica1;
    }

    public String getLeeryEscribir1() {
        return LeeryEscribir1;
    }

    public void setLeeryEscribir1(String LeeryEscribir1) {
        this.LeeryEscribir1 = LeeryEscribir1;
    }

    public char getInstruccion1() {
        return Instruccion1;
    }

    public void setInstruccion1(char Instruccion1) {
        this.Instruccion1 = Instruccion1;
    }

    public String getProvinciaContrayente1() {
        return ProvinciaContrayente1;
    }

    public void setProvinciaContrayente1(String ProvinciaContrayente1) {
        this.ProvinciaContrayente1 = ProvinciaContrayente1;
    }

    public String getCantonContrayente1() {
        return CantonContrayente1;
    }

    public void setCantonContrayente1(String CantonContrayente1) {
        this.CantonContrayente1 = CantonContrayente1;
    }

    public String getParroquiaContrayente1() {
        return ParroquiaContrayente1;
    }

    public void setParroquiaContrayente1(String ParroquiaContrayente1) {
        this.ParroquiaContrayente1 = ParroquiaContrayente1;
    }

    public String getLocalidadContrayente1() {
        return LocalidadContrayente1;
    }

    public void setLocalidadContrayente1(String LocalidadContrayente1) {
        this.LocalidadContrayente1 = LocalidadContrayente1;
    }

    @Override
    public String toString() {
        return "ClsContrayente{" + "NombreApellidos1=" + NombreApellidos1 + ", Nacionalidad1=" + Nacionalidad1 + ", CI1=" + CI1 + ", FechNacimiento1=" + FechNacimiento1 + ", Edad1=" + Edad1 + ", NumeroMatrimonios1=" + NumeroMatrimonios1 + ", EstadoCivil1=" + EstadoCivil1 + ", Etnica1=" + Etnica1 + ", LeeryEscribir1=" + LeeryEscribir1 + ", Instruccion1=" + Instruccion1 + ", ProvinciaContrayente1=" + ProvinciaContrayente1 + ", CantonContrayente1=" + CantonContrayente1 + ", ParroquiaContrayente1=" + ParroquiaContrayente1 + ", LocalidadContrayente1=" + LocalidadContrayente1 + '}';
    }
    
    
}

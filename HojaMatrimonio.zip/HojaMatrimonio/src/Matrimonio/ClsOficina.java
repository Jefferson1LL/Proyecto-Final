package Matrimonio;

public class ClsOficina {

    private String DireccionOficina;
    private String ProvinciaOficina;
    private String CantonOficina;
    private String ParroquiaOficina;
    private String FechaMatrimonio;
    private int ActaOficina;
    private int NumeroHijos;
    private char Bienes;

    public ClsOficina() {
    }

    public ClsOficina(String DireccionOficina, String ProvinciaOficina, String CantonOficina, String ParroquiaOficina, String FechaMatrimonio, int ActaOficina, int NumeroHijos, char Bienes) {
        this.DireccionOficina = DireccionOficina;
        this.ProvinciaOficina = ProvinciaOficina;
        this.CantonOficina = CantonOficina;
        this.ParroquiaOficina = ParroquiaOficina;
        this.FechaMatrimonio = FechaMatrimonio;
        this.ActaOficina = ActaOficina;
        this.NumeroHijos = NumeroHijos;
        this.Bienes = Bienes;
    }

    public String getDireccionOficina() {
        return DireccionOficina;
    }

    public void setDireccionOficina(String DireccionOficina) {
        this.DireccionOficina = DireccionOficina;
    }

    public String getProvinciaOficina() {
        return ProvinciaOficina;
    }

    public void setProvinciaOficina(String ProvinciaOficina) {
        this.ProvinciaOficina = ProvinciaOficina;
    }

    public String getCantonOficina() {
        return CantonOficina;
    }

    public void setCantonOficina(String CantonOficina) {
        this.CantonOficina = CantonOficina;
    }

    public String getParroquiaOficina() {
        return ParroquiaOficina;
    }

    public void setParroquiaOficina(String ParroquiaOficina) {
        this.ParroquiaOficina = ParroquiaOficina;
    }

    public String getFechaMatrimonio() {
        return FechaMatrimonio;
    }

    public void setFechaMatrimonio(String FechaMatrimonio) {
        this.FechaMatrimonio = FechaMatrimonio;
    }

    public int getActaOficina() {
        return ActaOficina;
    }

    public void setActaOficina(int ActaOficina) {
        this.ActaOficina = ActaOficina;
    }

    public int getNumeroHijos() {
        return NumeroHijos;
    }

    public void setNumeroHijos(int NumeroHijos) {
        this.NumeroHijos = NumeroHijos;
    }

    public char getBienes() {
        return Bienes;
    }

    public void setBienes(char Bienes) {
        this.Bienes = Bienes;
    }

    @Override
    public String toString() {
        return "ClsOficina{" + "DireccionOficina=" + DireccionOficina + ", ProvinciaOficina=" + ProvinciaOficina + ", CantonOficina=" + CantonOficina + ", ParroquiaOficina=" + ParroquiaOficina + ", FechaMatrimonio=" + FechaMatrimonio + ", ActaOficina=" + ActaOficina + ", NumeroHijos=" + NumeroHijos + ", Bienes=" + Bienes + '}';
    }

   
    
    
    
 
}

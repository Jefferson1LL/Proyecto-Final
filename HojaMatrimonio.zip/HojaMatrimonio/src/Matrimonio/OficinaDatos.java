/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matrimonio;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class OficinaDatos {
    
    private String mensaje="";
    public String agregarOficina(Connection con, ClsOficina ofi){
        
        PreparedStatement pst = null;
        String sql = "INSERT INTO NOMBREOFICINA (DireccionOficina,ProvinciaOficina,CantonOficina,ParroquiaOficina,FechaMatrimonio,ActaOficina,NumeroHijos,Bienes)"
                +"VALUES(?,?,?,?,?,?,?,?)";
        
        try {
            pst = con.prepareStatement(sql);
            pst.setString(1, ofi.getDireccionOficina());
            pst.setString(2, ofi.getProvinciaOficina()); 
            pst.setString(3, ofi.getCantonOficina());
            pst.setString(4, ofi.getParroquiaOficina());
            pst.setString(5, ofi.getFechaMatrimonio());
            pst.setInt(6, ofi.getActaOficina());
            pst.setInt(7, ofi.getNumeroHijos());
            pst.setString(8, ofi.getBienes()+"");
            mensaje ="Guardado correctamente";
            pst.execute();
            pst.close();
        } catch (SQLException e) {
            mensaje ="no se pudo guardar \n "+e.getMessage();
            
        }
        return mensaje;
    }
    
    
    
    public void listarempleado(Connection con){
        
    }
    
    
    public String agregarcontrayente(Connection con, ClsContrayente contra){
        
        PreparedStatement pst = null;
        String sql = "INSERT INTO DELCONTRAYENTE(NombreApellido1,Nacionalidad1,CI1,FechaNacimiento1,Edad1,NumeroMatrimonios1,EstadoCivil1,Etnica1,Leeryescibir1,Instruccion1,ProvinciaContrayente1,CantonContrayente1,ParroquiContrayente1,LocalidadContrayente1)"
                +"VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        
        try {
            pst = con.prepareStatement(sql);
            pst.setString(1, contra.getNombreApellidos1());
            pst.setString(2, contra.getNacionalidad1()+"");
            pst.setInt(3, contra.getCI1());
            pst.setString(4, contra.getFechNacimiento1());
            pst.setInt(5, contra.getEdad1());
            pst.setInt(6, contra.getNumeroMatrimonios1());
            pst.setString(7, contra.getEstadoCivil1()+"");
            pst.setString(8, contra.getEtnica1()+"");
            pst.setString(9, contra.getLeeryEscribir1());
            pst.setString(10, contra.getInstruccion1()+"");
            pst.setString(11, contra.getProvinciaContrayente1());
            pst.setString(12, contra.getCantonContrayente1());
            pst.setString(13, contra.getParroquiaContrayente1());
            pst.setString(14, contra.getLocalidadContrayente1());
            mensaje ="Guardado correctamente";
            pst.execute();
            pst.close();
        } catch (SQLException e) {
            mensaje ="no se pudo guardar \n "+e.getMessage();
            
        }
        return mensaje;
    }
    
    public String agregarlacontrayente(Connection con, ClslaContrayente lacontra){
        
        PreparedStatement pst = null;
        String sql = "INSERT INTO DELACONTRAYENTE(NombreApellido2,Nacionalidad2,CI2,FechaNacimiento2,Edad2,NumeroMatrimonios2,EstadoCivil2,Etnica2,Leeryescibir2,Instruccion2,ProvinciaContrayente2,CantonContrayente2,ParroquiContrayente2,LocalidadContrayente2)"
                +"VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        
        try {
            pst = con.prepareStatement(sql);
            pst.setString(1, lacontra.getNombreApellidos2());
            pst.setString(2, lacontra.getNacionalidad2()+"");
            pst.setInt(3, lacontra.getCI2());
            pst.setString(4, lacontra.getFechNacimiento2());
            pst.setInt(5, lacontra.getEdad2());
            pst.setInt(6, lacontra.getNumeroMatrimonios2());
            pst.setString(7, lacontra.getEstadoCivil2()+"");
            pst.setString(8, lacontra.getEtnica2()+"");
            pst.setString(9, lacontra.getLeeryEscribir2());
            pst.setString(10, lacontra.getInstruccion2()+"");
            pst.setString(11, lacontra.getProvinciaContrayente2());
            pst.setString(12, lacontra.getCantonContrayente2());
            pst.setString(13, lacontra.getParroquiaContrayente2());
            pst.setString(14, lacontra.getLocalidadContrayente2());
            mensaje ="Guardado correctamente";
            pst.execute();
            pst.close();
        } catch (SQLException e) {
            mensaje ="no se pudo guardar \n "+e.getMessage();
            
        }
        return mensaje;
    }
    
    public String agregarFuncionario(Connection con, ClsFuncionario fun){
        
        PreparedStatement pst = null;
        String sql = "INSERT INTO FUNCIONARIO(NombreApellidofuncionario,CIFuncionario,Observacion)"
                +"VALUES(?,?,?,?,?,?,?,?)";
        
        try {
            pst = con.prepareStatement(sql);
            pst.setString(1, fun.getNombreApellidoFuncionario());
            pst.setInt(2, fun.getCIFuncionario());
            pst.setString(3, fun.getObservacion());
            
            mensaje ="Guardado correctamente";
            pst.execute();
            pst.close();
        } catch (SQLException e) {
            mensaje ="no se pudo guardar \n "+e.getMessage();
            
        }
        return mensaje;
    }
    
   
}

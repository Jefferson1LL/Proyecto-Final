/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matrimonio;

/**
 *
 * @author PC-HOME
 */
public class ClsFuncionario {
    
    private String NombreApellidoFuncionario;
    private int CIFuncionario;
    private String Observacion;

    public ClsFuncionario() {
    }

    public ClsFuncionario(String NombreApellidoFuncionario, int CIFuncionario, String Observacion) {
        this.NombreApellidoFuncionario = NombreApellidoFuncionario;
        this.CIFuncionario = CIFuncionario;
        this.Observacion = Observacion;
    }

    public String getNombreApellidoFuncionario() {
        return NombreApellidoFuncionario;
    }

    public void setNombreApellidoFuncionario(String NombreApellidoFuncionario) {
        this.NombreApellidoFuncionario = NombreApellidoFuncionario;
    }

    public int getCIFuncionario() {
        return CIFuncionario;
    }

    public void setCIFuncionario(int CIFuncionario) {
        this.CIFuncionario = CIFuncionario;
    }

    public String getObservacion() {
        return Observacion;
    }

    public void setObservacion(String Observacion) {
        this.Observacion = Observacion;
    }

    @Override
    public String toString() {
        return "ClsFuncionario{" + "NombreApellidoFuncionario=" + NombreApellidoFuncionario + ", CIFuncionario=" + CIFuncionario + ", Observacion=" + Observacion + '}';
    }
    
    
}

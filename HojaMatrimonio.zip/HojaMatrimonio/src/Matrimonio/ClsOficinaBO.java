/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matrimonio;

import java.sql.Connection;

/**
 *
 * @author PC-HOME
 */
public class ClsOficinaBO {
    private String mensaje="";
    private OficinaDatos ofida = new OficinaDatos();
    
    public String agregarOficina( ClsOficina ofi){
        Connection conn = ClsConexion.getConnection();
        try {
            mensaje = ofida.agregarOficina(conn, ofi);
            conn.rollback();
        } catch (Exception e) {
            mensaje = mensaje+ " "+e.getMessage();
            
        }finally{
            try {
                if(conn != null){
                    conn.close();
                }
            } catch (Exception e) {
                mensaje = mensaje+ " "+e.getMessage();
            }
        }
        return mensaje;
    }
    
    public void listar(){
        
    }
    public String agregarcontrayente( ClsContrayente contra){
        Connection conn = ClsConexion.getConnection();
        try {
            mensaje = ofida.agregarcontrayente(conn, contra);
            conn.rollback();
        } catch (Exception e) {
            mensaje = mensaje+ " "+e.getMessage();
            
        }finally{
            try {
                if(conn != null){
                    conn.close();
                }
            } catch (Exception e) {
                mensaje = mensaje+ " "+e.getMessage();
            }
        }
        return mensaje;
    }
    
    public String agregarlacontrayente( ClslaContrayente lacontra){
        Connection conn = ClsConexion.getConnection();
        try {
            mensaje = ofida.agregarlacontrayente(conn, lacontra);
            conn.rollback();
        } catch (Exception e) {
            mensaje = mensaje+ " "+e.getMessage();
            
        }finally{
            try {
                if(conn != null){
                    conn.close();
                }
            } catch (Exception e) {
                mensaje = mensaje+ " "+e.getMessage();
            }
        }
        return mensaje;
    }
    
     public String agregarFuncionario( ClsFuncionario fun){
        Connection conn = ClsConexion.getConnection();
        try {
            mensaje = ofida.agregarFuncionario(conn, fun);
            conn.rollback();
        } catch (Exception e) {
            mensaje = mensaje+ " "+e.getMessage();
            
        }finally{
            try {
                if(conn != null){
                    conn.close();
                }
            } catch (Exception e) {
                mensaje = mensaje+ " "+e.getMessage();
            }
        }
        return mensaje;
    }
}
